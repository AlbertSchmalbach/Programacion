from setuptools import setup
setup(
    name="matematicos",
    version="0.1",
    description="modulos de calculos matematicos",
    author="Alberto Schmalbach",
    author_email="beto21048@gmail.com",
    packages=['matematicos'],
    scripts=[]
)